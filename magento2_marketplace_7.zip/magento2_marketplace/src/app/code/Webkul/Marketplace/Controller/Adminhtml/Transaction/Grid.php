<?php
namespace Webkul\Marketplace\Controller\Adminhtml\Transaction;

class Grid extends Index
{
    /**
     * set page data
     *
     * @return $this
     */
    public function setPageData()
    {
        return $this;
    }
}
