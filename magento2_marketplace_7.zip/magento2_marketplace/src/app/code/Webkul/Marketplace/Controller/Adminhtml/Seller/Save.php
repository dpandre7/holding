<?php
namespace Webkul\Marketplace\Controller\Adminhtml\Seller;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;

class Save extends \Magento\Backend\App\Action
{
    /**
     * File Uploader factory
     *
     * @var \Magento\MediaStorage\Model\File\UploaderFactory
     */
    protected $_fileUploaderFactory;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;

    /**
     * @var \Magento\Framework\Stdlib\DateTime
     */
    protected $dateTime;
     /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context,
            Filesystem $filesystem,
            \Magento\Framework\Stdlib\DateTime\DateTime $date,
            \Magento\Framework\Stdlib\DateTime $dateTime,
            \Magento\Store\Model\StoreManagerInterface $storeManager,
            \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
        )
    {
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_date = $date;
        $this->dateTime = $dateTime;
        $this->_storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
     * Check for is allowed
     *
     * @return boolean
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Webkul_Marketplace::seller');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        $resultRedirect = $this->resultRedirectFactory->create();
        $post = $this->getRequest()->isPost();
        if($post){
            if($this->getRequest()->getParam('seller_id') != ''){
                list($data, $errors) = $this->validateprofiledata();
                $fields = $this->getRequest()->getParams();
                $productIds = $this->getRequest()->getParam('sellerassignproid');
                $unassignproid = $this->getRequest()->getParam('sellerunassignproid');
                $seller_id=$this->getRequest()->getParam('seller_id');
                $partner_type = $this->getRequest()->getParam('partnertype');
                if($partner_type==2)
                {
                    $this->removePartner($seller_id);
                    return $resultRedirect->setPath('*/seller/index');
                }
                if($productIds !=''||$productIds!= 0){
                    $this->assignProduct($seller_id,$productIds);
                }
                if($unassignproid !=''||$unassignproid!= 0){
                    $this->unassignProduct($seller_id,$unassignproid);
                }

                $collectionselect = $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Saleperpartner')->getCollection()->addFieldToFilter('seller_id',$seller_id);
                if(count($collectionselect)==1){
                    foreach($collectionselect as $verifyrow){
                    $autoid=$verifyrow->getEntityId();
                    }
                    
                    $collectionupdate = $this->_objectManager->get('Webkul\Marketplace\Model\Saleperpartner')->load($autoid);
                    if(!isset($fields['commision'])){
                        $fields['commision'] = $collectionupdate->getCommissionRate();
                    }
                    $collectionupdate->setCommissionRate($fields['commision']);
                    $collectionupdate->save();
                    }
                else{
                    if(!isset($fields['commision'])){
                        $fields['commision'] = 0;
                    }
                    $collectioninsert=$this->_objectManager->create('Webkul\Marketplace\Model\Saleperpartner');
                    $collectioninsert->setSellerId($seller_id);
                    $collectioninsert->setCommissionRate($fields['commision']);
                    $collectioninsert->save();
                }
                 if(empty($errors)){ 
                    $auto_id = ''; 
                    $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')
                                    ->getCollection()
                                    ->addFieldToFilter('seller_id',$seller_id);
                    foreach($collection as  $value){
                        $auto_id = $value->getId();
                    }
                    if(!isset($fields['tw_active'])){
                        $fields['tw_active']=0;
                    }
                    if(!isset($fields['fb_active'])){
                        $fields['fb_active']=0;
                    }
                    if(!isset($fields['gplus_active'])){
                        $fields['gplus_active']=0;
                    }
                    if(!isset($fields['youtube_active'])){
                        $fields['youtube_active']=0;
                    }
                    if(!isset($fields['vimeo_active'])){
                        $fields['vimeo_active']=0;
                    }
                    if(!isset($fields['instagram_active'])){
                        $fields['instagram_active']=0;
                    }
                    if(!isset($fields['pinterest_active'])){
                        $fields['pinterest_active']=0;
                    }
                    if(!isset($fields['moleskine_active'])){
                        $fields['moleskine_active']=0;
                    }
                    $value = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')->load($auto_id);
                    $value->addData($fields);
                    $value->setIsSeller(1);
                    $value->setUpdatedAt($this->_date->gmtDate());
                    $value->save();
                    if(isset($fields['company_description'])){
                        $fields['company_description'] = str_replace('script', '', $fields['company_description']);
                        $value->setCompanyDescription($fields['company_description']);
                    }
        

                    if(isset($fields['return_policy'])){
                        $fields['return_policy'] = str_replace('script', '', $fields['return_policy']);
                        $value->setReturnPolicy($fields['return_policy']);
                    }               

                    if(isset($fields['shipping_policy'])){
                        $fields['shipping_policy'] = str_replace('script', '', $fields['shipping_policy']);
                        $value->setShippingPolicy($fields['shipping_policy']);
                    }               
                    if(isset($fields['meta_description'])){
                        $value->setMetaDescription($fields['meta_description']);
                    }    
                    $target = $this->_mediaDirectory->getAbsolutePath('avatar/');
                    if( isset($_FILES['banner_pic'])){
                        if(strlen($_FILES['banner_pic']['name'])>0){
                            $image = getimagesize($_FILES['banner_pic']['tmp_name']);
                            if($image['mime']) {
                                $img1 = rand(1,99999).$_FILES["banner_pic"]["name"];
                                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'banner_pic']);
                                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                                $uploader->setAllowRenameFiles(true);
                                $result = $uploader->save($target,$img1);
                                if($result['file']){                         
                                    $value->setBannerPic($result['file']);
                                }
                            }else{
                                $this->messageManager->addError(__("Disallowed file type."));
                            }
                        }
                    }
                    if( isset($_FILES['logo_pic'])){    
                        if(strlen($_FILES['logo_pic']['name'])>0){
                            $image = getimagesize($_FILES['logo_pic']['tmp_name']);
                            if($image['mime']) {
                                $img2 = rand(1,99999).$_FILES["logo_pic"]["name"];
                                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'logo_pic']);
                                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                                $uploader->setAllowRenameFiles(true);
                                $result = $uploader->save($target,$img2);
                                if($result['file']){                         
                                    $value->setLogoPic($result['file']);
                                }
                            }else{
                                $this->messageManager->addError(__("Disallowed file type."));
                            }
                        }
                    }    
                    if (array_key_exists('country_pic', $fields)) {
                        $value->setCountryPic($fields['country_pic']);
                    }
                    $value->save();
                    if ($this->getRequest()->getParam('back')) {
                        return $resultRedirect->setPath('*/*/edit', ['id' => $seller_id, '_current' => true]);
                    }
                    return $resultRedirect->setPath('*/seller/index');
                    }
            }else{
                $partner_type = $this->getRequest()->getParam('partnertype');
                $profileurl = $this->getRequest()->getParam('profileurl');
                $custmoer_id = 0;
                $customerid = $this->getRequest()->getParam('customerid');
                 $checkCustomer = $this->_objectManager->get('Magento\Customer\Model\Customer')->load($customerid);
                $custmoer_id = $checkCustomer->getEntityId();
                if($partner_type==1 && $custmoer_id != 0)
                {
                    $isAlreadySeller =$this->_objectManager->create('Webkul\Marketplace\Model\Seller')->getCollection()->addFieldToFilter('seller_id',$custmoer_id)
                                        ->addFieldToFilter('is_seller',1); 
                    if(count($isAlreadySeller)==0){
                        if($profileurl!=''){
                            $profileurlcount =$this->_objectManager->create('Webkul\Marketplace\Model\Seller')->getCollection();
                            $profileurlcount->addFieldToFilter('shop_url',$profileurl);
                            $seller_profile_id = 0;
                            $seller_profileurl = '';
                            $collectionselect = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')->getCollection();
                            $collectionselect->addFieldToFilter('seller_id',$customerid);
                            foreach($collectionselect as $coll){
                                $seller_profile_id = $coll->getEntityId();
                                $seller_profileurl = $coll->getProfileUrl();
                            }
                            if(count($profileurlcount) && ($profileurl!=$seller_profileurl)){
                                $this->messageManager->addError(__('This Shop Name alreasy Exists.'));
                            }else{
                                $collection=$this->_objectManager->get('Webkul\Marketplace\Model\Seller')->load($seller_profile_id);
                                $collection->setIsSeller(1);
                                $collection->setShopUrl($profileurl);
                                $collection->setSellerId($customerid);
                                $collection->setCreatedAt($this->_date->gmtDate());
                                $collection->setUpdatedAt($this->_date->gmtDate());
                                $collection->save();

                                $helper = $this->_objectManager->get('Webkul\Marketplace\Helper\Data');
                                $admin_storemail = $helper->getAdminEmailId();
                                $adminEmail=$admin_storemail? $admin_storemail:$helper->getDefaultTransEmailId();
                                $adminUsername = 'Admin';

                                $seller = $this->_objectManager->get('Magento\Customer\Model\Customer')->load($customerid);

                                $emailTempVariables['myvar1'] = $seller->getName();
                                $emailTempVariables['myvar2'] = $this->_storeManager->getStore()->getUrl('customer/account/login');
                                $senderInfo = [
                                    'name' => $adminUsername,
                                    'email' => $adminEmail,
                                ];
                                $receiverInfo = [
                                    'name' => $seller->getName(),
                                    'email' => $seller->getEmail(),
                                ];
                                $this->_objectManager->create('Webkul\Marketplace\Helper\Email')->sendSellerApproveMail($emailTempVariables,$senderInfo,$receiverInfo);

                                 $this->messageManager->addSuccess(__('New Seller successfully created.'));
                            }
                            if ($this->getRequest()->getParam('back')) {
                                return $resultRedirect->setPath('*/*/edit', ['id' => $custmoer_id, '_current' => true]);
                            }
                             return $resultRedirect->setPath('*/seller/index');
                        }
                        else{
                            $this->messageManager->addError(__("Enter Shop Name of Customer."));
                            return $resultRedirect->setPath('*/*/edit');
                        }
                    }else{
                         $this->messageManager->addError(__("Selected customer already assigned as Seller."));
                            return $resultRedirect->setPath('*/*/edit');
                    }

                }
            }
        }else{
            return $resultRedirect->setPath('*/*/edit', ['id' => $seller_id]);
        }    
    }
    private function validateprofiledata()
    {
        $errors = array();
        $data = array();
        foreach( $this->getRequest()->getParams() as $code => $value){
            switch ($code) :
                case 'twitter_id':
                    if(trim($value) != '' && preg_match('/[\'^£$%&*()}{@#~?><>, |=_+¬-]/', $value)){$errors[] = __('Twitterid cannot contain space and special charecters');} 
                    else{$data[$code] = $value;}
                    break;
                case 'facebook_id':
                    if(trim($value) != '' &&  preg_match('/[\'^£$%&*()}{@#~?><>, |=_+¬-]/', $value)){$errors[] = __('Facebookid cannot contain space and special charecters');} 
                    else{$data[$code] = $value;}
                    break;
            endswitch;
        }
        return array($data, $errors);
    }

    public function assignProduct($seller_id,$productIds){
        $productids=explode(',',$productIds);
        foreach($productids as $proid){
            $userid='';
            $product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($proid);
            if($product->getname()){   
                $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Product')->getCollection()->addFieldToFilter('mageproduct_id',array('eq'=>$proid));
                foreach($collection as $coll){
                   $userid = $coll['seller_id'];
                }
                if($userid){
                    $this->messageManager->addError(__("The product is already assigned to other seller."));
                }
                else{
                    $collection1 = $this->_objectManager->create('Webkul\Marketplace\Model\Product');
                    $collection1->setMageproductId($proid);
                    $collection1->setSellerId($seller_id);
                    $collection1->setStatus($product->getStatus());
                    $collection1->setAdminassign(1);
                    $collection1->setStoreId(array($this->_storeManager->getStore()->getId()));
                    $collection1->setCreatedAt($this->_date->gmtDate());
                    $collection1->setUpdatedAt($this->_date->gmtDate());
                    $collection1->save();
                    $this->messageManager->addSuccess(__("Products has been successfully assigned to seller."));
                }
            } else {
                $this->messageManager->addError(__("Product with id %s doesn't exist.",$proid));
            } 
        }
    }
    public function unassignProduct($seller_id,$productIds){
        $productids=explode(',',$productIds);
        foreach($productids as $proid){
            $userid='';
            $product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($proid);
            if($product->getname()){   
                $collection = $this->_objectManager->create('Webkul\Marketplace\Model\Product')->getCollection()->addFieldToFilter('mageproduct_id',$proid);
                foreach($collection as $coll){
                    $coll->delete();
                }
                $this->messageManager->addSuccess(__("Products has been successfully unassigned to seller."));
            } else {
                $this->messageManager->addSuccess(__("Product with id %s doesn't exist.",$proid));
            } 
        }
    }

    private function removePartner($seller_id)
    {
        $collectionselectdelete = $this->_objectManager->create('Webkul\Marketplace\Model\Seller')->getCollection();
        $collectionselectdelete->addFieldToFilter('seller_id',$seller_id);
        foreach($collectionselectdelete as $delete){
            $autoid=$delete->getEntityId();
        }
        $collectiondelete = $this->_objectManager->get('Webkul\Marketplace\Model\Seller')->load($autoid);
        $collectiondelete->delete();
        $helper = $this->_objectManager->get('Webkul\Marketplace\Helper\Data');
        $admin_storemail = $helper->getAdminEmailId();
        $adminEmail=$admin_storemail? $admin_storemail:$helper->getDefaultTransEmailId();
        $adminUsername = 'Admin';

        $seller = $this->_objectManager->get('Magento\Customer\Model\Customer')->load($seller_id);

        $emailTempVariables['myvar1'] = $seller->getName();
        $emailTempVariables['myvar2'] = $this->_storeManager->getStore()->getUrl('customer/account/login');
        $senderInfo = [
            'name' => $adminUsername,
            'email' => $adminEmail,
        ];
        $receiverInfo = [
            'name' => $seller->getName(),
            'email' => $seller->getEmail(),
        ];
        $this->_objectManager->create('Webkul\Marketplace\Helper\Email')->sendSellerDisapproveMail($emailTempVariables,$senderInfo,$receiverInfo);

        $this->messageManager->addSuccess(__("Seller successfully removed."));
    }
}