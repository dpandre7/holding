var config = {
    map: {
        '*': {
            colorpicker: 'Webkul_Marketplace/js/colorpicker',
            productGallery:     'Webkul_Marketplace/js/product-gallery',
            baseImage:          'Webkul_Marketplace/catalog/base-image-uploader',
            newVideoDialog:  'Webkul_Marketplace/js/new-video-dialog',
            openVideoModal:  'Webkul_Marketplace/js/video-modal',
            configurableAttribute:  'Webkul_Marketplace/catalog/product/attribute',
            notification: 'mage/backend/notification',
            productAttributes:  'Webkul_Marketplace/catalog/product-attributes',
            verifySellerShop: 'Webkul_Marketplace/js/account/verify-seller-shop'
        }
    },
    paths: {
        "colorpicker": 'js/colorpicker'
    },
    "shim": {
        "colorpicker" : ["jquery"]
    }
};
