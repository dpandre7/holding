<?php
    /**
     * Webkul ImageGallery Groups Edit Tabs Admin Block
     *
     * @category    Webkul
     * @package     Webkul_ImageGallery
     * @author      Webkul Software Private Limited
     *
     */
    namespace Webkul\Marketplace\Block\Adminhtml\Seller\Edit;

    use Magento\Backend\Block\Template\Context;
    use Magento\Framework\Translate\InlineInterface;
    use Magento\Framework\Json\EncoderInterface;
    use Magento\Backend\Model\Auth\Session;

    class Tabs extends \Magento\Backend\Block\Widget\Tabs
    {

            /**
         * @var InlineInterface
         */
        protected $_translateInline;
        /**
         * 
         * @var null
         */
        protected $_objectManager = null;

        public function __construct(
            Context $context,
            InlineInterface $translateInline,
            EncoderInterface $jsonEncoder,
            Session $authSession,
            \Magento\Framework\ObjectManagerInterface $objectManager,
            array $data = []
        ) {
            $this->_translateInline = $translateInline;
            $this->_objectManager = $objectManager;
            parent::__construct($context, $jsonEncoder, $authSession, $data);
        }
        /**
         * @return void
         */
        protected function _construct()
        {
            parent::_construct();
            $this->setId('seller_tabs');
            $this->setDestElementId('edit_form');
            $this->setTitle(__('Seller Information'));
        }

        /**
         * Prepare Layout
         *
         * @return $this
         */
        protected function _prepareLayout()
        {
            $coll = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getMarketplaceUserCollection();
            $isSeller = 0;
            foreach($coll as $row){
                $isSeller=$row->getIsSeller();
            }
            if($isSeller){
                $this->addTab(
                    'sellerinfo',
                    [
                        'label' => __('Seller Information'),
                        'content' => $this->_translateHtml($this->getSellerInformation()),
                    ]
                );
                $this->addTab(
                    'paymentinfo',
                    [
                        'label' => __('Payment Information'),
                        'content' => $this->_translateHtml($this->getPaymentInfo()
                            ),
                    ]
                );
                $this->addTab(
                    'commission',
                    [
                        'label' => __('Commission'),
                        'content' => $this->_translateHtml($this->getCommission()
                            ),
                    ]
                );
                $this->addTab(
                    'add_product',
                    [
                        'label' => __('Add Prduct'),
                        'content' => $this->_translateHtml($this->getAddProduct()
                            ),
                    ]
                );
                $this->addTab(
                    'remove_product',
                    [
                        'label' => __('Remove Product'),
                        'content' => $this->_translateHtml($this->getRemoveProduct()
                            ),
                    ]
                );
                
                $this->addTab(
                    'remove_seller',
                    [
                        'label' => __('Do You Want To Remove This Seller?'),
                        'content' => $this->_translateHtml($this->removeSellerTabData()
                            ),
                    ]
                );
            }else{
                $this->addTab(
                    'remove_product',
                    [
                        'label' => __('Do You Want To Make This Customer As Seller?'),
                        'content' => $this->_translateHtml($this->addSellerTabData()
                            ),
                    ]
                );
            }    
            // $this->addTab(
            //     'images',
            //     [
            //         'label' => __('Galleries'),
            //         'class' => 'ajax'
            //     ]
            // );
            return parent::_prepareLayout();
        }

         /**
     * Translate html content
     *
     * @param string $html
     * @return string
     */
        protected function _translateHtml($html)
        {
            $this->_translateInline->processResponseBody($html);
            return $html;
        }

        public function getSellerInformation(){
            $partner = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getSellerInfoCollection();
            $tw_active = '';
            $fb_active = '';
            $gplus_active = '';
            $instagram_active = '';
            $youtube_active = '';
            $vimeo_active = '';
            $pinterest_active = '';
            $moleskine_active = '';
            if($partner['tw_active'] == 1){ 
                $tw_active = "checked='checked'";
            }
            if($partner['fb_active'] == 1){ 
                $fb_active = "checked='checked'";
            }
            if($partner['gplus_active'] == 1){ 
                $gplus_active = "checked='checked'";
            }
            if($partner['instagram_active'] == 1){ 
                $instagram_active = "checked='checked'";
            }
            if($partner['youtube_active'] == 1){ 
                $youtube_active = "checked='checked'";
            }
            if($partner['vimeo_active'] == 1){ 
                $vimeo_active = "checked='checked'";
            }
            if($partner['pinterest_active'] == 1){ 
                $pinterest_active = "checked='checked'";
            }
            if($partner['moleskine_active'] == 1){ 
                $moleskine_active = "checked='checked'";
            }
            $options ='';
            foreach($this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getCountryList() as $country){
                if($country['value']!=''){
                    $selectedval = $partner['country_pic']==$country['value']?"selected='selected'":"";
                }
                if($country['value'])
                    $options = $options.'<option '.$selectedval.' value="'.$country['value'].'">'.$country['label'].'</option>';
            }

            $html = '<div class="admin__fieldset-wrapper opened">
                        <div class="admin__fieldset-wrapper-title">
                            <strong class="title">
                                <span data-bind="text: label">'.__('Seller Information').'</span>
                            </strong>
                        </div>
                        <div class="admin__fieldset-wrapper-content">
                        <fieldset class="admin__fieldset">
                            <div class="admin__field">
                            <label class="admin__field-label" for="twitter_id">
                                <span>'.__('Twitter ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="twitter_id" class="admin__control-text" type="text" value="'.$partner['twitter_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="tw_active" value="1" title="'.__('Allow to Display Twitter Icon in Profile Page').'" '.$tw_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="facebook_id">
                                <span data-bind="text: element.label">'.__('Facebook ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="facebook_id" class="admin__control-text" type="text" value="'.$partner['facebook_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="fb_active" value="1" title="'.__('Allow to Display Facebook Icon in Profile Page').' '.$fb_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="instagram_id">
                                <span data-bind="text: element.label">'.__('Instagram ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="instagram_id" class="admin__control-text" type="text" value="'.$partner['instagram_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="instagram_active" value="1" title="'. __('Allow to Display Instagram Icon in Profile Page').'"'.$instagram_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="gplus_id">
                                <span data-bind="text: element.label">'.__('Google Plus ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="gplus_id" class="admin__control-text" type="text" value="'.$partner['gplus_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="gplus_active" value="1" title="'.__('Allow to Display Google Plus Icon in Profile Page').'" '.$gplus_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="youtube_id">
                                <span data-bind="text: element.label">'.__('Youtube ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="youtube_id" class="admin__control-text" type="text" value="'.$partner['youtube_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="youtube_active" value="1" title="'.__('Allow to Display Youtube Icon in Profile Page').'" '.$youtube_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="vimeo_id">
                                <span data-bind="text: element.label">'.__('Vimeo ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="vimeo_id" class="admin__control-text" type="text" value="'.$partner['vimeo_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="vimeo_active" value="1" title="'.__('Allow to Display Vimeo Icon in Profile Page').'" '.$vimeo_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="pinterest_id">
                                <span data-bind="text: element.label">'.__('Pinterest ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="pinterest_id" class="admin__control-text" type="text" value="'.$partner['pinterest_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="pinterest_active" title="'.__('Allow to Display Pinterest Icon in Profile Page').'" '.$pinterest_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="moleskine_id">
                                <span data-bind="text: element.label">'.__('Moleskine ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="moleskine_id" class="admin__control-text" type="text" value="'.$partner['moleskine_id'].'">
                            </div>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="moleskine_active" title="'.__('Allow to Display Moleskine Icon in Profile Page').'" '.$moleskine_active.' style="margin-left:10px;">
                                <label style="margin-left:10px;" class="admin__field-label"></label>
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="contact_number">
                                <span data-bind="text: element.label">'.__('Contact Number').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="contact_number" class="admin__control-text" type="text" value="'.$partner['contact_number'].'" placeholder="'.__('Enter Mobile Number with country code.').'">
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="shop_title">
                                <span data-bind="text: element.label">'.__('Shop Title').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="shop_title" class="admin__control-text" type="text" value="'.$partner['shop_title'].'">
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="company_locality">
                                <span data-bind="text: element.label">'.__('Company Locality').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="company_locality" class="admin__control-text" type="text" value="'.$partner['company_locality'].'">
                            </div> 
                        </div>
                        <div class="admin__field">
                    <label class="admin__field-label" for="country_pic">
                        <span data-bind="text: element.label">'.__('Country').'</span>
                    </label>
                    <div class="admin__field-control">
                        <select class="admin__control-select" name="country_pic" id="country_pic" placeholder="">
                            <option value="" selected="selected" disabled="disabled">
                                '.__("Select Country").'
                            </option>'.$options.'
                        </select>
                    </div>
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="company_description">
                        <span data-bind="text: element.label">'.__('Company Description').'</span>
                    </label>
                    <div class="admin__field-control">
                        <textarea type="text" id="company_description" name="company_description" title=" '.__('Company Description').'" class="admin__control-textarea"> '.$partner['company_description'].'</textarea>
                    </div> 
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="return_policy">
                        <span data-bind="text: element.label">'.__('Return Policy').'</span>
                    </label>
                    <div class="admin__field-control">
                        <textarea type="text" id="return_policy" name="return_policy" title=" '.__('Return Policy').'" class="admin__control-textarea"> '.$partner['return_policy'].'</textarea>
                    </div> 
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="shipping_policy">
                        <span data-bind="text: element.label">'.__('Shipping Policy').'</span>
                    </label>
                    <div class="admin__field-control">
                        <textarea type="text" id="shipping_policy" name="shipping_policy" title=" '.__('Shipping Policy').'" class="admin__control-textarea"> '.$partner['shipping_policy'].'</textarea>
                    </div> 
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="meta_keyword">
                        <span data-bind="text: element.label">'.__('Meta Keywords').'</span>
                    </label>
                    <div class="admin__field-control">
                        <textarea type="text" id="meta_keyword" name="meta_keyword" title=" '.__('Meta Keywords').'" class="admin__control-textarea"> '.$partner['meta_keyword'].'</textarea>
                    </div> 
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="meta_description">
                        <span data-bind="text: element.label">'.__('Meta Description').'</span>
                    </label>
                    <div class="admin__field-control">
                        <textarea type="text" id="meta_description" name="meta_description" title=" '.__('Meta Description').'" class="admin__control-textarea"> '.$partner['meta_description'].'</textarea>
                    </div> 
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="banner_pic">
                        <span data-bind="text: element.label">'.__('Company Banner').'</span>
                    </label>
                    <div class="admin__field-control">
                       <input name="banner_pic" class="admin__control-file" type="file">
                       <img style="margin:5px 0;width:700px;height:150px;" src="'.$this->getBaseUrl().'pub/media/avatar/'.$partner['banner_pic'].'"/>
                    </div> 
                </div>
                <div class="admin__field">
                    <label class="admin__field-label" for="logo_pic">
                        <span data-bind="text: element.label">'.__('Company Logo').'</span>
                    </label>
                    <div class="admin__field-control">
                       <input name="logo_pic" class="admin__control-file" type="file">
                       <img style="margin:5px 0;width:100px;" src="'.$this->getBaseUrl().'pub/media/avatar/'.$partner['logo_pic'].'"/>
                    </div> 
                </div>
                    </fieldset>
                    </div>
                </div>';
            return $html;   
        }

        public function getPaymentInfo(){
            $paymentInfo = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getPaymentMode();
            if($paymentInfo != ''){
                $html = '<div class="admin__fieldset-wrapper opened">
                    <div class="admin__fieldset-wrapper-title">
                        <strong class="title">
                            <span data-bind="text: label">'.__('Payment Information').'</span>
                        </strong>
                    </div>
                    <div class="admin__fieldset-wrapper-content">
                        <fieldset class="admin__fieldset">
                            <address>
                               '.$paymentInfo.'
                            </address>   
                        </fieldset>
                    </div>
                </div>';
                return $html;
            }else{
                $html = '<div class="admin__fieldset-wrapper opened">
                    <div class="admin__fieldset-wrapper-title">
                        <strong class="title">
                            <span data-bind="text: label">'.__('Payment Information').'</span>
                        </strong>
                    </div>
                    <div class="admin__fieldset-wrapper-content">
                        <fieldset class="admin__fieldset">
                            <address>
                               '.__('Not Mentioned Yet.').'
                            </address>   
                        </fieldset>
                    </div>
                </div>';
                return $html;
            }
        }

        public function getCommission(){
            $collection = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getSalesPartnerCollection();
            if(count($collection)) {
                foreach ($collection as $value) {
                    $rowcom = $value->getCommissionRate();
                }   
            }
            else
            {
              $rowcom = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getConfigCommissionRate(); 
            }
            $tsale=0;
            $tcomm=0;
            $tact=0;
            $collection1 = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getSalesListCollection();    
            foreach ($collection1 as $key) {
                    $tsale+=$key->getTotalAmount();
                    $tcomm+=$key->getTotalCommission();
                    $tact+=$key->getActualSellerAmount();
                }       

            $comm = $rowcom;

            $currencySymbol =  $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getCurrencySymbol();


            $html = '<div class="admin__fieldset-wrapper opened">
                <div class="admin__fieldset-wrapper-title">
                    <strong class="title">
                        <span data-bind="text: label">'.__('Commission Details').'</span>
                    </strong>
                </div>
                <div class="admin__fieldset-wrapper-content">
                    <fieldset class="admin__fieldset">
                        <div class="admin__field">
                            <label class="admin__field-label" for="commission">
                                <span data-bind="text: element.label">'.__('Set Commission In Percentage For This Seller').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="commision" class="admin__control-text" type="text" value="'.$rowcom.'">
                            </div> 
                        </div>
                        <table class="admin__table-secondary">
                            <tbody>
                                <tr>
                                    <th>'.__('Total Sale').'</th>
                                    <td>'.$currencySymbol.' '.$tsale.'</td>
                                </tr>
                                <tr>
                                    <th>'.__('Total Seller Sale').'</th>
                                    <td>'.$currencySymbol.' '.$tact.'</td>
                                </tr>
                                <tr>
                                    <th>'.__('Total Admin Sale').'</th>
                                    <td>'.$currencySymbol.' '.$tcomm.'</td>
                                </tr>
                                <tr>
                                    <th>'.__('Current Commission %').'</th>
                                    <td>'.$comm.'%'.'</td>
                                </tr>
                            </tbody>
                        </table>    
                    </fieldset>
                </div>
            </div>';
            return $html;
        }

        public function getAddProduct(){
            $coll = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getProductCollection(); 
           $productids=array();
            foreach($coll as $row){
                array_push($productids, $row->getMageproductId());
            }
            if(count($productids))
                $proids= implode(',', $productids);
            else
                $proids= 'none';

            $html = '<div class="admin__fieldset-wrapper opened">
                <div class="admin__fieldset-wrapper-title">
                    <strong class="title">
                        <span data-bind="text: label">'.__('Assign Product To Seller').'</span>
                    </strong>
                </div>
                <div class="admin__fieldset-wrapper-content">
                    <fieldset class="admin__fieldset">
                        <div class="admin__field">
                            <label class="admin__field-label" for="sellerassignproid">
                                <span data-bind="text: element.label">'.__('Enter Product ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="sellerassignproid" class="admin__control-text" type="text" value="">
                                <span class="note"><span><b>'.__('Notice: Enter Only Integer value by comma (,)').'</span></b></span>
                            </div> 
                        </div>
                        <table class="admin__table-secondary">
                            <tbody>
                                <tr>
                                    <th>'.__('Assigned Product Ids').'</th>
                                    <td>'.$proids.'</td>
                                </tr>
                            </tbody>
                        </table>          
                    </fieldset>
                </div>
            </div>';

            return $html;
        }

        public function getRemoveProduct(){
            return '<div class="admin__fieldset-wrapper opened">
                <div class="admin__fieldset-wrapper-title">
                    <strong class="title">
                        <span data-bind="text: label">'.__('Unassign Product To Seller').'</span>
                    </strong>
                </div>
                <div class="admin__fieldset-wrapper-content">
                    <fieldset class="admin__fieldset">
                        <div class="admin__field">
                            <label class="admin__field-label" for="sellerassignproid">
                                <span data-bind="text: element.label">'.__('Enter Product ID').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="sellerunassignproid" class="admin__control-text" type="text" value="">
                                <span class="note"><span><b>'.__('Notice: Enter Only Integer value by comma (,)').'</span></b></span>
                            </div> 
                        </div>          
                    </fieldset>
                </div>
            </div>';
        }

        public function addSellerTabData(){
            $coll = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getMarketplaceUserCollection();
            $profileurl='';
            foreach($coll as $row){
                $profileurl=$row->getShopUrl();
            }

            $customers = $this->_objectManager->create('Webkul\Marketplace\Block\Adminhtml\Seller\Edit')->getAllCustomerCollection();
             $options ='';
            foreach ($customers as $customer) {
                $options = $options.'<option value="'.$customer->getId().'">'.$customer->getName().'</option>';
            }

            $html = '<div class="admin__fieldset-wrapper opened">
                <div class="admin__fieldset-wrapper-title">
                    <strong class="title">
                        <span data-bind="text: label">'.__('Do You Want To Make This Customer As Seller ?').'</span>
                    </strong>
                </div>
                <div class="admin__fieldset-wrapper-content">
                    <fieldset class="admin__fieldset">
                        <div class="admin__field">
                            <label class="admin__field-label" for="profileurl">
                                <span>'.__('Customer Name').'</span>
                            </label>
                            <div class="admin__field-control">
                        <select class="admin__control-select" name="customerid" id="customerid" placeholder="">
                            <option value="" selected="selected" disabled="disabled">
                                '.__("Select Customer").'
                            </option>'.$options.'
                        </select>
                    </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="profileurl">
                                <span>'.__('Shop Name').'</span>
                            </label>
                            <div class="admin__field-control">
                                <input name="profileurl" class="admin__control-text profileurl" type="text" value="'.$profileurl.'">
                            </div> 
                        </div>
                        <div class="admin__field">
                            <label class="admin__field-label" for="partnertype">
                                <span></span>
                            </label>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="partnertype" value="1">
                                <label class="admin__field-label"><span>'.__('Approve Seller').'</span></label>
                            </div> 
                        </div>         
                    </fieldset> 
                </div>
            </div>
            <script>
                require([
                    "jquery",
                    "mage/mage"
                ], function($){
                    $(".profileurl").keyup(function(){
                            $(this).val($(this).val().replace(/[^a-z^0-9\.]/g,""));
                        });
                });
            </script>';

            return $html;
        }

        public function removeSellerTabData()
        {
            return '<div class="admin__fieldset-wrapper opened">
                <div class="admin__fieldset-wrapper-title">
                    <strong class="title">
                        <span data-bind="text: label">'.__('Do You Want To Remove This Seller ?').'</span>
                    </strong>
                </div>
                <div class="admin__fieldset-wrapper-content">
                    <fieldset class="admin__fieldset">
                        <div class="admin__field">
                            <label class="admin__field-label" for="sellerassignproid">
                                <span></span>
                            </label>
                            <div class="admin__field admin__field-option">
                                <input type="checkbox" class="admin__control-checkbox" name="partnertype" value="2">
                                <label class="admin__field-label"><span>'.__('Check To Unapprove Seller').'</span></label>
                            </div> 
                        </div>          
                    </fieldset>
                </div>
            </div>';
        }

    }