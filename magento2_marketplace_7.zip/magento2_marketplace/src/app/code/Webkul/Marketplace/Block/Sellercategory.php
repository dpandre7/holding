<?php
namespace Webkul\Marketplace\Block;
/**
 * Webkul Marketplace Sellercategory Block
 *
 * @category    Webkul
 * @package     Webkul_Marketplace
 * @author      Webkul Software Private Limited
 *
 */

use Magento\Catalog\Model\Category;

class Sellercategory extends \Magento\Framework\View\Element\Template
{

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var ObjectManagerInterface
     */
    protected $category;

    /**
    * @param Context $context
    * @param array $data
     * @param \Magento\Cms\Model\Template\FilterProvider $filterProvider
    * @param \Magento\Framework\ObjectManagerInterface $objectManager
    */
    public function __construct(
        Category $category,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        $this->Category = $category;
        $this->_objectManager = $objectManager;
        parent::__construct($context, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * @return array
     */
    public function getProfileDetail($value='')
    {
        $shop_url = $this->_objectManager->create('Webkul\Marketplace\Helper\Data')->getCollectionUrl();
        if(!$shop_url){
            $shop_url = $this->getRequest()->getParam('shop');            
        }
        if($shop_url){
            $data=$this->_objectManager->create('Webkul\Marketplace\Model\Seller')
                    ->getCollection()
                    ->addFieldToFilter('shop_url',array('eq'=>$shop_url));
            foreach($data as $seller){ return $seller;}
        }
    }   

    public function getCategoryList(){    	
		$seller_id=$this->getProfileDetail()->getSellerId();
		$querydata = $this->_objectManager->create('Webkul\Marketplace\Model\Product')
							->getCollection()
			                ->addFieldToFilter('seller_id', array('eq' => $seller_id))
			                ->addFieldToFilter('status', array('neq' => 2))
			                ->addFieldToSelect('mageproduct_id')
			                ->setOrder('mageproduct_id');
        $collection = $this->_objectManager->create('Magento\Catalog\Model\Product')->getCollection();
        $collection->addAttributeToSelect('*');
        
        $collection->addAttributeToFilter('entity_id', array('in' => $querydata->getData()));
        $collection-> addAttributeToFilter('visibility', array('in' => array(4) )); 
        $collection->addStoreFilter();
        //Mage::getSingleton('cataloginventory/stock')->addInStockFilterToCollection($collection);
        //Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($collection);

        $collectionConfigurable = $this->_objectManager->create('Magento\Catalog\Model\Product')
    									->getCollection()
		        						->addAttributeToFilter('type_id', array('eq' => 'configurable'))
		        						->addAttributeToFilter('entity_id', array('in' => $querydata->getData()));

		$outOfStockConfis = array();
		foreach ($collectionConfigurable as $_configurableproduct) {
		    $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($_configurableproduct->getId());
		    if (!$product->getData('is_salable')) {
		       $outOfStockConfis[] = $product->getId();
		    }
		}
		if(count($outOfStockConfis)){
			$collection->addAttributeToFilter('entity_id',array('nin' => $outOfStockConfis));
		}

		$collectionBundle = $this->_objectManager->create('Magento\Catalog\Model\Product')
								->getCollection()
        						->addAttributeToFilter('type_id', array('eq' => 'bundle'))
        						->addAttributeToFilter('entity_id', array('in' => $querydata->getData()));
		$outOfStockConfis = array();
		foreach ($collectionBundle as $_bundleproduct) {
		    $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($_bundleproduct->getId());
		    if (!$product->getData('is_salable')) {
		       $outOfStockConfis[] = $product->getId();
		    }
		}
		if(count($outOfStockConfis)){
			$collection->addAttributeToFilter('entity_id',array('nin' => $outOfStockConfis));
		}

		$collectionGrouped = $this->_objectManager->create('Magento\Catalog\Model\Product')
								->getCollection()
        						->addAttributeToFilter('type_id', array('eq' => 'bundle'))
        						->addAttributeToFilter('entity_id', array('in' => $querydata->getData()));
		$outOfStockConfis = array();
		foreach ($collectionGrouped as $_groupedproduct) {
		    $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($_groupedproduct->getId());
		    if (!$product->getData('is_salable')) {
		       $outOfStockConfis[] = $product->getId();
		    }
		}
		if(count($outOfStockConfis)){
			$collection->addAttributeToFilter('entity_id',array('nin' => $outOfStockConfis));
		}
		
		$products = $this->_objectManager->create('Webkul\Marketplace\Model\Product')
							->getCollection()
							->addFieldToFilter('mageproduct_id',array('in'=>$collection->getData()))
							->addFieldToSelect('mageproduct_id');

		$eavAttribute = $this->_objectManager->get('Magento\Eav\Model\ResourceModel\Entity\Attribute');
        $pro_att_id = $eavAttribute->getIdByCode("catalog_category","name");

        $storeId = $this->_objectManager->create('Webkul\Marketplace\Helper\Data')->getCurrentStoreId();
        if(!isset($_GET["c"])){
			$_GET["c"] ='';
		}
       	if(!$_GET["c"]){
        	$parentid = $this->_objectManager->create('Webkul\Marketplace\Helper\Data')->getRootCategoryIdByStoreId($storeId);
        }else{
        	$parentid = $_GET["c"];
        }
        $catalog_category_product = $this->_objectManager->create('Webkul\Marketplace\Model\ResourceModel\Seller\Collection')->getTable('catalog_category_product');
        $catalog_category_entity =$this->_objectManager->create('Webkul\Marketplace\Model\ResourceModel\Seller\Collection')->getTable('catalog_category_entity');
        $catalog_category_entity_varchar = $this->_objectManager->create('Webkul\Marketplace\Model\ResourceModel\Seller\Collection')->getTable('catalog_category_entity_varchar');

        $products->getSelect()
        ->join(array("ccp" => $catalog_category_product),"ccp.product_id = main_table.mageproduct_id",array("category_id" => "category_id"))
        ->join(array("cce" => $catalog_category_entity),"cce.entity_id = ccp.category_id",array("parent_id" => "parent_id"))->where("cce.parent_id = '".$parentid."'")
        ->columns('COUNT(*) AS countCategory')
        ->group('category_id')
        ->join(array("ce1" => $catalog_category_entity_varchar),"ce1.entity_id = ccp.category_id",array("catname" => "value"))->where("ce1.attribute_id = ".$pro_att_id)
        ->order('catname');
        return $products;
	} 
}

