<?php
    /**
     * Webkul ImageGallery Groups Edit Form Admin Block
     *
     * @category    Webkul
     * @package     Webkul_ImageGallery
     * @author      Webkul Software Private Limited
     *
     */
    namespace Webkul\Marketplace\Block\Adminhtml\Seller\Edit;

    class Form extends \Magento\Backend\Block\Widget\Form\Generic
    {
        /**
         * @var \Magento\Store\Model\System\Store
         */
        protected $_systemStore;
        
        /**
         * Core registry
         *
         * @var \Magento\Framework\Registry
         */
        protected $_coreRegistry;

        /**
         * @param \Magento\Backend\Block\Template\Context $context
         * @param \Magento\Framework\Registry $registry
         * @param \Magento\Framework\Data\FormFactory $formFactory
         * @param \Magento\Store\Model\System\Store $systemStore
         * @param array $data
         */
        public function __construct(
            \Magento\Backend\Block\Template\Context $context,
            \Magento\Framework\Registry $registry,
            \Magento\Framework\Data\FormFactory $formFactory,
            \Magento\Store\Model\System\Store $systemStore,
            array $data = []
        ) {
            $this->_systemStore = $systemStore;
            $this->_coreRegistry = $registry;
            parent::__construct($context, $registry, $formFactory, $data);
        }

        /**
         * Init form
         *
         * @return void
         */
        protected function _construct()
        {
            parent::_construct();
            $this->setId('seller_form');
            $this->setTitle(__('Seller Information'));
        }

        /**
         * Prepare form
         *
         * @return $this
         */
        protected function _prepareForm()
        {
            //$model = $this->_coreRegistry->registry('imagegallery_groups');
            $form = $this->_formFactory->create(
                ['data' => ['id' => 'edit_form', 'enctype' => 'multipart/form-data', 'action' => $this->getData('action'), 'method' => 'post']]
            );
            $form->addField(
                'seller_id',
                'hidden',
                [
                    'name' => 'seller_id',
                    'value' => $this->getRequest()->getParam('id')
                ]
            );
            //$form->setValues($model->getData());
            $form->setUseContainer(true);
            $this->setForm($form);
            return parent::_prepareForm();
        }
    }